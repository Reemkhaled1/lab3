# DM324 - Internet Technology

## Assignment (Make Sure to Bring newstudent.html file your next week)
Create newstudent.html and add the following form:
![alt text](https://github.com/fue-edu/DM324-Internet_Technology/blob/Fall-2021-lab-03/newstudent-form.png)

Feel Free to add other form inputs. 

